# BoxingBot V2.0.2 — first live-run checklist

1. Create/activate your virtual environment and install `Requirements.txt`.
2. Copy `.env.example` to `.env` and set `DISCORD_TOKEN` (plus `FFMPEG_PATH` only if FFmpeg is not on PATH).
3. Start with `python run_bot.py` and confirm all cogs load and slash commands sync.
4. Run `/menu`; create/edit a linked boxer and confirm the 60-point, 5–11-per-stat validation.
5. Test `/start` → `/fight` → `/next_round`; confirm an unfinished fight cannot be overwritten by another `/start`.
6. Join voice and verify fighter intro music, crowd ambience, commentary clips, final bell and cheer.
7. Add one test round GIF and one finish GIF using `MEDIA_ASSET_GUIDE.md`; confirm both appear, then remove them to verify missing-media fallback still works.
8. Create a tournament, register two or more boxers, edit a registered boxer before starting, then start and confirm the latest build is locked.
9. Open **Admin Centre → Tournament Control → Director Dashboard** and use **Stage Next Bout**.
10. Complete a tournament bout and confirm bracket advancement, career stats, achievements and tournament report update once.
11. Force/test a tournament draw if practical; confirm the career records a draw while the tournament bout remains pending for a rematch.
12. Restart the bot during a staged/in-progress test fight and verify fight-session recovery.
13. Run Competition Audit and SQLite diagnostics from the admin menus.

Do not commit `.env`, `boxing_v2.sqlite3`, `fight_sessions.json`, backups, virtual environments or generated cache files.
