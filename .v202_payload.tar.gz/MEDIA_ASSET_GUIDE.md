# BoxingBot V2.0.2 Media Asset Guide

Media is optional: missing files degrade gracefully and never stop a bout/result. Paths are project-root stable.

## Core presentation
- `graphics/ring.gif` — ring/fight-night presentation
- `graphics/round_mm.gif`, `round_mf.gif`, `round_ff.gif` — generic round GIF fallbacks

## Round highlight GIFs
Folder: `graphics/promo/rounds/`
Pattern: `{mm|mf|ff}_{red|blue}_{jab|cross|hook|uppercut|glancing|miss|low_blow|knockdown}.gif`

## Finish GIFs
Folder: `graphics/promo/finish/`
Pattern: `{mm|mf|ff}_{red|blue}_{ko|tko|points}.gif`

## Commentary
Folder: `graphics/promo/commentary/`
Recognised generic clips include `KD.mp3`, `Low_Blow.mp3`, `Swing_Miss.mp3`, `Tidy_Block.mp3`. Corner clips use names such as `Red_Jab.mp3`, `Blue_Cross.mp3`, `Red_Hook.mp3`, `Blue_Uppercut.mp3`, `Red_Pressure.mp3`, `Blue_Momentum.mp3`. Filename matching is case-insensitive in V2.0.2, so legacy `Red_hook.mp3` also works.

## Music / ambience
Folder: `graphics/music/`
- fighter intro tracks: any selected `.mp3` filename
- `crowd_ambience.mp3` — pre-fight ambience
- `crowd.mp3` — fight crowd loop
- `cheer.mp3` — finish cheer
- `ambient/Bell.mp3` — final bell

Promo-only music belongs in `graphics/promo/music/`; `hype.mp3` is preferred.

## Judges / promo art
- `graphics/judges/` — decision cards
- `graphics/promo/<boxer>.png|jpg|webp` — boxer promo images
- `graphics/promo/background.png` — poster background
- `graphics/promo/icons/flame.png` — optional flame overlay (case-insensitive)
- `graphics/promo/fonts/` — `BebasNeue-Regular.ttf`, `Anton-Regular.ttf`, or `Impact.ttf`

## FFmpeg
Set `FFMPEG_PATH` in `.env` if FFmpeg is not on PATH. Playback diagnostics and normal audio use the same resolver.
