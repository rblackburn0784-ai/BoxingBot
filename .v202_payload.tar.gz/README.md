# BoxingBot V2.0.2

A persistent Discord boxing game built on the stabilised V2 fight engine.

The main player entry point is `/menu`. Each Discord user can own one linked boxer, edit their build outside active tournaments, build a permanent career, settle grudge matches, earn achievements and compete in persistent tournaments. Admins operate tournaments and live bouts through the V2 Admin Centre and Tournament Director.

## Competitive rules
- exactly **60** base stat points
- each stat must be **5–11**
- fixed **100 HP**
- XP, level, prestige, titles and achievements are status/progression only and never add combat power
- tournament builds snapshot when the tournament starts

## Media
All media is optional and missing files fail gracefully. See `MEDIA_ASSET_GUIDE.md` for the exact commentary, GIF, music, judge-card and promo-art folders/filenames.

See `V2.0.2_RELEASE_NOTES.md` for the current release changes and `RUN_V2_CHECKLIST.md` before the first live server run.
